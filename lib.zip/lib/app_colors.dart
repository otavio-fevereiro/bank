library bank.colors;

import 'dart:ui';

class AppColors {
  static const Color purple = Color(0xFF6A2374);
  static const Color withe = Color(0xFFF5F5F5);
  static const Color gray = Color(0xFF9D9D9D);
}